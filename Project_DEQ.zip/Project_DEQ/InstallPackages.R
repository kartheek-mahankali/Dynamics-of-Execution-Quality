# Set the CRAN mirror
options(repos = "https://cloud.r-project.org")

packages <- c(
  "Hmisc","weights", "kableExtra", "tidytext", "yaml", "config", "knitr", 
  "formatR", "tibble", "dplyr", "tidyr", "lubridate", "ggplot2",
  "ggfortify", "caret", "tsibble", "fable", "fabletools", "feasts",
  "tsibbledata", "data.table", "xtable", "data.table", "rvest", "httr"
)

install.packages(packages)

for (pkg in packages) {
  library(pkg, character.only = TRUE)
}
